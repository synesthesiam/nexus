' =============================================================================
'
'      h-ittsdk.vb -- H-ITT SDK Visual Basic .NET Header File  
'    
'      Copyright (c) 2001-2009 www.h-itt.com
'
'      For Visual Basic 6 use h-ittsdk.vb6
'
'      For more information and technical support visit www.h-itt.com
'
' ============================================================================
'
Public Const HITT_ERROR As Integer = 1
Public Const HITT_OK As Integer = 0
'
' hitt_inspect - use to get remote ID number and key pressed from bytes
' read on COM port
'
' pass a reference to the array of 10 characters
' function will fill in id and key_code if valid
'
' returns:
'
'  HITT_OK   ....   success
'       pid will containt the Remote ID number and
'       pkey_code will contain the numeric key code
'
'  HITT_ERROR   ....   error - throw away first byte and tack
'             next set of bytes read on end and call
'             again.
'
'
'  === KEY CODES ===
'
Public Const HITT_KEY_A As Integer = 1
Public Const HITT_KEY_B As Integer = 2
Public Const HITT_KEY_C As Integer = 3
Public Const HITT_KEY_D As Integer = 4
Public Const HITT_KEY_E As Integer = 5
Public Const HITT_KEY_F As Integer = 6
Public Const HITT_KEY_G As Integer = 7
Public Const HITT_KEY_H As Integer = 8
Public Const HITT_KEY_I As Integer = 9
Public Const HITT_KEY_J As Integer = 10
Public Const HITT_KEY_FORWARD As Integer = 0
Public Const HITT_KEY_REVERSE As Integer = 11
'
Declare Function 
hitt_inspect 
Lib "H-ITTSDK.dll" (ByRef Bytes As Byte, ByRef id As Integer, ByRef key_code As Integer) As Integer
'
'
'
' hitt_action_packet - use to form actions packet of 5 bytes
' to send out on COM port
'
' Bytes must be an array of length >= 5
'
' returns:
'
'  HITT_OK   ....   success
'
'  HITT_ERROR   ....   error - either invalid code
'               or array not proper length
'
'  === ACTION CODES ===
'
Public Const HITT_AC_RED                        As Integer = 0
Public Const HITT_AC_GREEN                      As Integer = 1
Public Const HITT_AC_YELLOW                     As Integer = 2
Public Const HITT_AC_BLINK_RED                  As Integer = 3
Public Const HITT_AC_BLINK_GREEN                As Integer = 4
Public Const HITT_AC_BLINK_YELLOW               As Integer = 5
Public Const HITT_AC_TOGGLE_RED_GREEN           As Integer = 6
Public Const HITT_AC_FAST_BLINK_RED             As Integer = 7
Public Const HITT_AC_FAST_BLINK_GREEN           As Integer = 8
Public Const HITT_AC_FAST_BLINK_YELLOW          As Integer = 9
Public Const HITT_AC_FAST_TOGGLE_RED_GREEN      As Integer = 10
Public Const HITT_AC_OFF                        As Integer = 11
'
Declare Function 
hitt_action_packet 
Lib "H-ITTSDK.dll" (ByRef Bytes As Byte, ByRef id As Integer, ByVal action_code As Integer) As Integer
'
'
'
' hitt_drid_inspect - use to get remote ID and other data from LCD remotes.
' must first put base unit in DRID mode see hitt_base_unit_packet.  Then collect
' 32 bytes (HITT_DRID_INSPECT_NUM_BYTES) and the pass to function
' If return is HITT_OK data is valid.
' If return is HITT_ERROR discard first byte then tack on additional bytes read from port and reprocess
'
'returns:
'
'  HITT_OK   ....   success
'
'  HITT_ERROR   ....   error - either invalid code or null pointers
'
'    if drid_type == HITT_DRID_TESTING_MODE then
'    question_number contains the valid question number and
'    assignment_number contains the valid assignment number
'    otherwise question_number and assignment_number are ignored
'
'    remotes send up to max 20 characters so declare your Data buffer to
'    hold 21 (HITT_DATA_BUFFER_LEN) to account for the NULL character
'    at the end.
'
Public Const HITT_DRID_NORMAL           As Integer = 1
Public Const HITT_DRID_ROSTER_MODE      As Integer = 2
Public Const HITT_DRID_TESTING_MODE     As Integer = 64
Public Const HITT_DATA_BUFFER_LEN       As Integer = 21
'
Declare Function 
hitt_drid_inspect 
Lib "H-ITTSDK.dll" (ByRef Bytes As Byte, ByRef id As Integer, ByRef drid_type As Integer, ByRef question_number As Integer, ByRef assignment_number As Integer, ByRef Data As Byte) As Integer
'
'
'
' hitt_base_unit_mode  - used to get packet to send to base units to put it into DRID (long packet) or normal multple choice (short packet mode)
'
'returns:
'
'  HITT_OK   ....   success
'
'  HITT_ERROR   ....   error - invalid code or null pointer
'
Public Const HITT_BASE_UNIT_NORMAL              As Integer = 0
Public Const HITT_BASE_UNIT_DRID                As Integer = 1
'
Declare Function 
hitt_base_unit_mode 
Lib "H-ITTSDK.dll" (ByRef Bytes As Byte, ByVal mode As Integer) As Integer
'
'
'
'
' hitt_sdk_version gets version of SDK.  puts version string in version, where length is size of version
'
Declare Function 
hitt_sdk_version 
Lib "H-ITTSDK.dll" (ByRef version As Byte, ByVal length As Integer) As Integer

